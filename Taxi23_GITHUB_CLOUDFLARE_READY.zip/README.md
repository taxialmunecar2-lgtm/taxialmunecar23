# Taxi 23 — GitHub / Cloudflare Pages

Web estática preparada para publicar directamente desde este repositorio.

## Cloudflare Pages
- Framework preset: None
- Build command: (vacío) o `exit 0`
- Build output directory: `/`
- Production branch: `main`

El proyecto conserva `_redirects` y `_headers` para Cloudflare Pages.
